// app.c — top-level menu (Mode 1 unchanged; Mode 2 simplified)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
  #define SIM_CMD ".\\sim_gen.exe"
  #define CALC_CMD ".\\cpu_calc.exe"
  #define PY_PLOT "python plot_core_trace.py"
#else
  #define SIM_CMD "./sim_gen"
  #define CALC_CMD "./cpu_calc"
  #define PY_PLOT "python3 plot_core_trace.py"
#endif

static int read_int(const char *p){
    int x; for(;;){
        printf("%s", p); fflush(stdout);
        if (scanf("%d",&x)==1) return x;
        int c; while((c=getchar())!='\n' && c!=EOF){}; puts("Invalid input. Try again.");
    }
}

static void build_cmd(char *dst, size_t cap, const char *base,
                      const char *a1, const char *a2, const char *a3,
                      const char *a4, const char *a5){
    dst[0]='\0';
    strncat(dst, base, cap-1);
    if (a1 && *a1){ strncat(dst, " ", cap-1); strncat(dst, a1, cap-1); }
    if (a2 && *a2){ strncat(dst, " ", cap-1); strncat(dst, a2, cap-1); }
    if (a3 && *a3){ strncat(dst, " ", cap-1); strncat(dst, a3, cap-1); }
    if (a4 && *a4){ strncat(dst, " ", cap-1); strncat(dst, a4, cap-1); }
    if (a5 && *a5){ strncat(dst, " ", cap-1); strncat(dst, a5, cap-1); }
}

int main(void){
    for(;;){
        puts("\n=== CPU Scheduling App ===");
        puts("1) Simulator + Calculator");
        puts("2) Optimal Scheduler (manual entry only)");
        puts("0) Quit");
        int mode = read_int("Enter choice: ");
        if (mode==0) break;

        if (mode==1){
            puts("\n[Simulator + Calculator]");
            puts("Workload source:");
            puts("  1) Job Generator");
            puts("  2) Manual Entry (calculator)");
            puts("  3) Preset");
            int src = read_int("Select [1-3]: ");

            puts("\nScheduler type:");
            puts("  1) FCFS  2) SJF  3) Priority  4) Round Robin");
            int s = read_int("Select [1-4]: ");
            const char* algo = (s==2)?"sjf":(s==3)?"pri":(s==4)?"rr":"fcfs";
            char qarg[64]="";
            if (s==4){
                int q = read_int("  RR time slice (ticks): ");
                snprintf(qarg, sizeof(qarg), "--quantum %d", (q>0)?q:1);
            }

            if (src==2){
                // Manual entry → table only; dump for plotting; then sim auto-plots
#ifdef _WIN32
                const char *dump = ".\\._calc_workload.tmp";
#else
                const char *dump = "._calc_workload.tmp";
#endif
                char tcmd[512], pflag[64], dflag[256];
                snprintf(pflag,sizeof(pflag),"--policy=%s", algo);
                snprintf(dflag,sizeof(dflag),"--dump=%s", dump);
                build_cmd(tcmd, sizeof(tcmd), CALC_CMD,
                          pflag, (s==4)?qarg:NULL, "--table-only", dflag, NULL);
                (void)system(tcmd);

                int cores = read_int("\nNumber of cores for plot: ");
                char acore[64]; snprintf(acore,sizeof(acore),"--cores=%d", (cores>0)?cores:1);
                char scmd[512], aload[300];
                snprintf(aload,sizeof(aload),"--load=%s", dump);
                build_cmd(scmd, sizeof(scmd), SIM_CMD,
                          "--ui=load", (s==4)?qarg:NULL, acore, aload, NULL);
                strncat(scmd, " --algo ", sizeof(scmd)-strlen(scmd)-1);
                strncat(scmd, algo, sizeof(scmd)-strlen(scmd)-1);
                strncat(scmd, " --norandio", sizeof(scmd)-strlen(scmd)-1);
                (void)system(scmd);
                (void)system(PY_PLOT);
            } else if (src==1){
                char cmd[512];
                build_cmd(cmd, sizeof(cmd), SIM_CMD, "--ui=gen",
                          (s==4)?qarg:NULL, NULL, NULL, NULL);
                strncat(cmd, " --algo ", sizeof(cmd)-strlen(cmd)-1);
                strncat(cmd, algo, sizeof(cmd)-strlen(cmd)-1);
                (void)system(cmd);
                (void)system(PY_PLOT);
            } else {
                puts("\nPreset size:");
                puts("  1) Small (4)");
                puts("  2) Medium (10)");
                puts("  3) Large (20)");
                int sz = read_int("Select [1-3]: ");
                if (sz<1||sz>3) sz=1;
                int cores = read_int("Number of cores: ");
                char apreset[32]; snprintf(apreset,sizeof(apreset),"--preset=%d", sz);
                char acore[64];   snprintf(acore,sizeof(acore),"--cores=%d", (cores>0)?cores:1);
                char cmd[512];
                build_cmd(cmd, sizeof(cmd), SIM_CMD, "--ui=preset",
                          apreset, acore, NULL, NULL);
                strncat(cmd, " --algo ", sizeof(cmd)-strlen(cmd)-1);
                strncat(cmd, algo, sizeof(cmd)-strlen(cmd)-1);
                strncat(cmd, " ", sizeof(cmd)-strlen(cmd)-1);
                strncat(cmd, (s==4)?qarg:"", sizeof(cmd)-strlen(cmd)-1);
                strncat(cmd, " --norandio", sizeof(cmd)-strlen(cmd)-1);
                (void)system(cmd);
                (void)system(PY_PLOT);
            }

        } else if (mode==2){
            // Let the calculator prompt for cores itself (fixes the “stuck” behavior)
#ifdef _WIN32
            (void)system(".\\cpu_calc.exe --optimal");
#else
            (void)system("./cpu_calc --optimal");
#endif

        } else {
            puts("Unknown choice.");
        }
    }
    return 0;
}
