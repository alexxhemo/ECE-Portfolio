// CPU_Scheduler.c — calculator + optimal mode
// - --optimal             : prompts for #cores, tasks, RR quantum; compares FCFS/SJF/PRI/RR
// - --policy=fcfs|sjf|pri|rr [--quantum N] [--table-only] [--dump=FILE]
//     manual entry once; prints table only if --table-only; optional dump for sim plotting
//
// Multi-core, predetermined I/O (loops with CPU and IO per loop; trailing IO optional).

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int id, arrival, loops, cpu, io, priority, include_last_io;
    int first_start, last_cpu_finish;
} Task;

typedef struct Ev { int when, idx; struct Ev* next; } Ev;

static int read_int(const char *p){
    int x;
    for(;;){
        printf("%s", p);
        fflush(stdout);
        if (scanf("%d",&x)==1) return x;
        // clear garbage
        int c; while((c=getchar())!='\n' && c!=EOF){};
        puts("Invalid input. Try again.");
    }
}

static void read_tasks(Task *a,int n,int ask_prio){
    for(int i=0;i<n;i++){
        a[i].id = i+1;
        printf("\n-- Task %d --\n", i+1);
        a[i].arrival = read_int("Arrival time: ");
        int loops = read_int("Number of loops (0 for single burst): ");
        a[i].loops = loops;
        if (loops==0){
            a[i].cpu = read_int("CPU burst length: ");
            a[i].io  = 0;
        } else {
            a[i].cpu = read_int("CPU per loop: ");
            a[i].io  = read_int("I/O per loop: ");
        }
        a[i].include_last_io = read_int("Include trailing I/O after last CPU in turnaround? (0/1): ");
        a[i].priority = ask_prio ? read_int("Priority (lower=better): ") : 0;
        a[i].first_start = -1;
        a[i].last_cpu_finish = -1;
    }
}

static void compute_row(const Task* t, int *wait, int *turn){
    int total_cpu = (t->loops==0)? t->cpu : t->loops*t->cpu;
    int total_io_between = (t->loops>1)? (t->loops-1)*t->io : 0;
    int trailing = t->include_last_io ? t->io : 0;
    int end_with_io = t->last_cpu_finish + trailing;
    int turnv = end_with_io - t->arrival;
    int waitv = turnv - total_cpu - total_io_between - trailing;
    if (waitv < 0) waitv = 0;
    *wait = waitv; *turn = turnv;
}

static void compute_avgs(const Task* a,int n,double *avg_wait,double *avg_turn){
    long sw=0, st=0;
    for(int i=0;i<n;i++){ int w,t; compute_row(&a[i],&w,&t); sw+=w; st+=t; }
    *avg_wait=(double)sw/n; *avg_turn=(double)st/n;
}

static void print_table(const char* name, const Task* a,int n){
    printf("\n== %s ==\n", name);
    printf("ID  Arr  Loops  CPU  IO  Pri  Start  Finish  Wait  Turn\n");
    for(int i=0;i<n;i++){
        int w,t; compute_row(&a[i],&w,&t);
        printf("%-3d %-4d %-5d %-4d %-3d %-4d %-6d %-7d %-5d %-5d\n",
            a[i].id, a[i].arrival, a[i].loops, a[i].cpu, a[i].io, a[i].priority,
            a[i].first_start, a[i].last_cpu_finish, w, t);
    }
}

/* -------- pickers (FCFS/SJF/PRI) for single selection steps -------- */
static int pick_fcfs(const Task* a,const int* released,const int* rem_cpu,int n){
    int p=-1;
    for(int i=0;i<n;i++){
        if(!released[i] || rem_cpu[i]<=0) continue;
        if(p==-1 || a[i].arrival<a[p].arrival || (a[i].arrival==a[p].arrival && a[i].id<a[p].id)) p=i;
    }
    return p;
}
static int pick_sjf(const Task* a,const int* released,const int* rem_cpu,int n){
    int p=-1;
    for(int i=0;i<n;i++){
        if(!released[i] || rem_cpu[i]<=0) continue;
        if(p==-1 ||
           rem_cpu[i] < rem_cpu[p] ||
          (rem_cpu[i]==rem_cpu[p] &&
            (a[i].arrival < a[p].arrival ||
             (a[i].arrival==a[p].arrival && a[i].id < a[p].id)))) p=i;
    }
    return p;
}
static int pick_pri(const Task* a,const int* released,const int* rem_cpu,int n){
    int p=-1;
    for(int i=0;i<n;i++){
        if(!released[i] || rem_cpu[i]<=0) continue;
        if(p==-1 ||
           a[i].priority < a[p].priority ||
          (a[i].priority==a[p].priority &&
            (a[i].arrival < a[p].arrival ||
             (a[i].arrival==a[p].arrival && a[i].id < a[p].id)))) p=i;
    }
    return p;
}

/* -------- simulation (multi-core, predetermined IO) -------- */
/* policy: 1=FCFS 2=SJF 3=PRI 4=RR(quantum) */
static void simulate(Task* in,int n,int policy,int quantum,int ncores){
    Task *a = (Task*)malloc(n*sizeof(Task)); memcpy(a,in,n*sizeof(Task));
    int *rem_loop = (int*)malloc(n*sizeof(int));
    int *rem_cpu  = (int*)malloc(n*sizeof(int));
    int *released = (int*)calloc(n,sizeof(int));
    for(int i=0;i<n;i++){
        rem_loop[i] = (a[i].loops==0)?1:a[i].loops;
        rem_cpu[i]  = a[i].cpu;
        a[i].first_start = -1;
        a[i].last_cpu_finish = -1;
    }
    Ev *wait=NULL;

    int *run = (int*)malloc(sizeof(int)*ncores);
    int *slice = (int*)malloc(sizeof(int)*ncores);
    for(int c=0;c<ncores;c++){ run[c]=-1; slice[c]=0; }

    // simple RR queue
    int rq_cap = n*8 + 32;
    int *rq = (int*)malloc(sizeof(int)*rq_cap);
    int rq_h=0, rq_t=0; // [rq_h, rq_t)
    #define RQ_EMPTY (rq_h>=rq_t)
    #define RQ_PUSH(x) do{ if(rq_t<rq_cap) rq[rq_t++]=(x); }while(0)
    #define RQ_POP()  (RQ_EMPTY?-1:rq[rq_h++])

    int time=0;
    while (1){
        // completed?
        int done=1; for(int i=0;i<n;i++) if(rem_loop[i]>0){ done=0; break; }
        if (done) break;

        // admit arrivals
        for(int i=0;i<n;i++) if(!released[i] && a[i].arrival<=time) released[i]=1;
        // IO completions
        while(wait && wait->when<=time){
            Ev* e=wait; wait=wait->next; released[e->idx]=1; free(e);
        }

        // bind to idle cores
        for(int c=0;c<ncores;c++){
            if (run[c]!=-1) continue;
            int pick=-1;
            if (policy==4){
                // RR: try queue first
                while(!RQ_EMPTY){
                    int cand=RQ_POP();
                    if (released[cand] && rem_cpu[cand]>0){ pick=cand; break; }
                }
                if (pick==-1){
                    for(int i=0;i<n;i++) if(released[i] && rem_cpu[i]>0){ pick=i; break; }
                }
            } else if (policy==1) pick=pick_fcfs(a,released,rem_cpu,n);
              else if (policy==2) pick=pick_sjf(a,released,rem_cpu,n);
              else pick=pick_pri(a,released,rem_cpu,n);

            if (pick!=-1){
                run[c]=pick;
                if (a[pick].first_start<0) a[pick].first_start=time;
                if (policy==4) slice[c]=(quantum>0)?quantum:1;
            }
        }

        // if nothing running, jump to next event
        int any=0; for(int c=0;c<ncores;c++){ if(run[c]!=-1){ any=1; break; } }
        if (!any){
            int next = 1e9;
            // next arrival
            for(int i=0;i<n;i++) if(!released[i] && a[i].arrival<next) next=a[i].arrival;
            // next IO completion
            if (wait && wait->when < next) next = wait->when;
            if (next<1e9){ time = next; continue; }
            else break; // nothing else can happen
        }

        // run one tick on all running cores
        time += 1;
        for(int c=0;c<ncores;c++){
            if (run[c]==-1) continue;
            int i=run[c];
            rem_cpu[i]-=1;
            if (policy==4) slice[c]-=1;
        }

        // handle completions / preemptions
        for(int c=0;c<ncores;c++){
            if (run[c]==-1) continue;
            int i=run[c];
            if (rem_cpu[i]==0){
                a[i].last_cpu_finish=time;
                rem_loop[i]-=1;
                if (rem_loop[i]>0){
                    // go to IO
                    int unblock=time+a[i].io;
                    Ev* e=(Ev*)malloc(sizeof(Ev));
                    e->when=unblock; e->idx=i; e->next=NULL;
                    if(!wait || unblock<wait->when){ e->next=wait; wait=e; }
                    else { Ev* p=wait; while(p->next && p->next->when<=unblock) p=p->next; e->next=p->next; p->next=e; }
                    released[i]=0;
                    rem_cpu[i]=a[i].cpu; // next CPU loop
                } else {
                    released[i]=0; // fully done
                }
                run[c]=-1;
            } else if (policy==4 && slice[c]==0){
                // RR preempt
                if (released[i] && rem_cpu[i]>0) RQ_PUSH(i);
                run[c]=-1;
            }
        }
    }

    // write back
    for(int i=0;i<n;i++){
        in[i].first_start=a[i].first_start;
        in[i].last_cpu_finish=a[i].last_cpu_finish;
    }
    // cleanup
    while(wait){ Ev* e=wait; wait=wait->next; free(e); }
    free(a); free(rem_loop); free(rem_cpu); free(released);
    free(run); free(slice); free(rq);
}

/* -------- wrappers -------- */
static void dump_workload(const char* path,const Task* a,int n){
    FILE* f=fopen(path,"w");
    if(!f){ perror("dump"); return; }
    for(int i=0;i<n;i++){
        int burst = (a[i].loops==0)? a[i].cpu : a[i].loops*a[i].cpu;
        if (burst<=0) burst=1;
        fprintf(f, "%d,%d,%d\n", a[i].id, a[i].arrival, burst);
    }
    fclose(f);
}

/* ============================ main ============================ */
int main(int argc, char** argv){
    int optimal=0, have_policy=0, policy=1, quantum=1, table_only=0;
    int ncores=1;             // only used by --optimal
    char dumpfile[256]; dumpfile[0]='\0';

    // unbuffer stdout so prompts always show up
    setvbuf(stdout, NULL, _IONBF, 0);

    for (int i=1;i<argc;i++){
        if (!strncmp(argv[i],"--policy=",9)){
            const char* s=argv[i]+9;
            if (!strcmp(s,"fcfs")||!strcmp(s,"fifo")) { policy=1; have_policy=1; }
            else if (!strcmp(s,"sjf"))               { policy=2; have_policy=1; }
            else if (!strcmp(s,"pri")||!strcmp(s,"priority")) { policy=3; have_policy=1; }
            else if (!strcmp(s,"rr"))                { policy=4; have_policy=1; }
        } else if (!strcmp(argv[i],"--quantum") && i+1<argc){
            quantum = atoi(argv[++i]); if (quantum<=0) quantum=1;
        } else if (!strcmp(argv[i],"--table-only")){
            table_only = 1;
        } else if (!strncmp(argv[i],"--dump=",7)){
            strncpy(dumpfile, argv[i]+7, 255); dumpfile[255]='\0';
        } else if (!strcmp(argv[i],"--optimal")){
            optimal = 1;
        } else if (!strncmp(argv[i],"--cores=",8)){
            ncores = atoi(argv[i]+8); if (ncores<=0) ncores=1;
        }
    }

    if (optimal){
        // Everything happens here (fixes “stuck” behavior)
        printf("\n=== Optimal Scheduler ===\n");
        if (ncores<=0) ncores = read_int("Number of cores to evaluate: ");
        int n = read_int("How many tasks? ");
        Task* a=(Task*)calloc(n,sizeof(Task));
        read_tasks(a,n,1);
        int q = read_int("Round Robin quantum for comparison: ");
        if (q<=0) q=1;

        Task *b1=malloc(n*sizeof(Task)), *b2=malloc(n*sizeof(Task)), *b3=malloc(n*sizeof(Task)), *b4=malloc(n*sizeof(Task));
        memcpy(b1,a,n*sizeof(Task)); memcpy(b2,a,n*sizeof(Task)); memcpy(b3,a,n*sizeof(Task)); memcpy(b4,a,n*sizeof(Task));

        simulate(b1,n,1,0,ncores);
        simulate(b2,n,2,0,ncores);
        simulate(b3,n,3,0,ncores);
        simulate(b4,n,4,q,ncores);

        double aw1,at1, aw2,at2, aw3,at3, aw4,at4;
        compute_avgs(b1,n,&aw1,&at1);
        compute_avgs(b2,n,&aw2,&at2);
        compute_avgs(b3,n,&aw3,&at3);
        compute_avgs(b4,n,&aw4,&at4);

        printf("\n=== Comparison on %d core(s) ===\n", ncores);
        printf("FCFS     : waiting %.3f, turnaround %.3f\n", aw1, at1);
        printf("SJF      : waiting %.3f, turnaround %.3f\n", aw2, at2);
        printf("Priority : waiting %.3f, turnaround %.3f\n", aw3, at3);
        printf("RR(q=%d) : waiting %.3f, turnaround %.3f\n", q, aw4, at4);

        double best_w=aw1; const char* bw="FCFS";
        if (aw2<best_w){ best_w=aw2; bw="SJF"; }
        if (aw3<best_w){ best_w=aw3; bw="Priority"; }
        if (aw4<best_w){ best_w=aw4; bw="RR"; }

        double best_t=at1; const char* bt="FCFS";
        if (at2<best_t){ best_t=at2; bt="SJF"; }
        if (at3<best_t){ best_t=at3; bt="Priority"; }
        if (at4<best_t){ best_t=at4; bt="RR"; }

        printf("\nOptimal by average waiting   : %s\n", bw);
        printf("Optimal by average turnaround: %s\n", bt);

        free(b1); free(b2); free(b3); free(b4); free(a);
        return 0;
    }

    // Single-policy manual entry (used by Mode 1 "Manual Entry")
    if (have_policy){
        int n = read_int("How many tasks? ");
        Task* a=(Task*)calloc(n,sizeof(Task));
        int ask_pri = (policy==3);
        read_tasks(a,n,ask_pri);

        // simulate just to fill Start/Finish, then print TABLE ONLY
        simulate(a,n,policy,quantum,1);
        print_table((policy==1)?"FCFS":(policy==2)?"SJF":(policy==3)?"PRIORITY":"RR", a, n);

        if (dumpfile[0]) dump_workload(dumpfile,a,n);
        free(a);
        return 0;
    }

    // Fallback interactive (rarely used)
    puts("\n=== Calculator ===");
    puts("1) FCFS");
    puts("2) SJF (non-preemptive)");
    puts("3) Priority (non-preemptive, lower=better)");
    puts("4) Round Robin (preemptive)");
    int c = read_int("Select [1-4]: ");
    int n = read_int("How many tasks? ");
    Task* a=(Task*)calloc(n,sizeof(Task));
    int ask_pri=(c==3);
    read_tasks(a,n,ask_pri);
    int q=1; if (c==4) q=read_int("Time quantum: ");
    simulate(a,n,c,q,1);
    print_table((c==1)?"FCFS":(c==2)?"SJF":(c==3)?"PRIORITY":"RR", a, n);
    free(a);
    return 0;
}
