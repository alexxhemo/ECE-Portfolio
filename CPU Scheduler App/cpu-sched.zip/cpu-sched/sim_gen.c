#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "sim.h"
#include "cpu.h"
#include "util.h"

#define MAX_TICKS 100000
#define MAX_CORES 64
#define PRIO_MAP_SIZE 10000

/* ---------------- tiny io helpers ---------------- */
static int read_int(const char *p){
    int x; for(;;){
        printf("%s", p); fflush(stdout);
        if (scanf("%d",&x)==1) return x;
        int c; while((c=getchar())!='\n' && c!=EOF){}; puts("Invalid input. Try again.");
    }
}
static int read_01(const char *p){ int v; do{ v=read_int(p);}while(v!=0 && v!=1); return v; }
static int rnd(int a,int b){ return a + rand() % (b - a + 1); }

/* ---------------- CLI ---------------- */
typedef enum { UI_GEN, UI_PRESET, UI_LOAD } UIMode;
typedef enum { ALG_FIFO=1, ALG_SJF=2, ALG_PRIORITY=3, ALG_RR=4 } Algo;

static void parse_args(int argc, char** argv,
                       UIMode* ui, Algo* algo, int* quantum, int* cores,
                       int* preset, char* loadfn, int* no_randio){
    *ui=UI_GEN; *algo=ALG_FIFO; *quantum=1; *cores=1; *preset=1; *loadfn=0; *no_randio=0;
    loadfn[0]='\0';
    for (int i=1;i<argc;i++){
        if (!strncmp(argv[i],"--ui=",5)){
            const char* s=argv[i]+5;
            if (!strcmp(s,"gen")) *ui=UI_GEN;
            else if (!strcmp(s,"preset")) *ui=UI_PRESET;
            else if (!strcmp(s,"load")) *ui=UI_LOAD;
        } else if (!strcmp(argv[i],"--algo") && i+1<argc){
            const char* s=argv[++i];
            if (!strcmp(s,"sjf")) *algo=ALG_SJF;
            else if (!strcmp(s,"pri")||!strcmp(s,"priority")) *algo=ALG_PRIORITY;
            else if (!strcmp(s,"rr")) *algo=ALG_RR;
            else *algo=ALG_FIFO;
        } else if (!strcmp(argv[i],"--quantum") && i+1<argc){
            *quantum = atoi(argv[++i]); if (*quantum<=0) *quantum=1;
        } else if (!strncmp(argv[i],"--cores=",8)){
            *cores = atoi(argv[i]+8); if (*cores<=0) *cores=1;
        } else if (!strncmp(argv[i],"--preset=",9)){
            *preset = atoi(argv[i]+9); if (*preset<1||*preset>3) *preset=1;
        } else if (!strncmp(argv[i],"--load=",7)){
            strncpy(loadfn, argv[i]+7, 255); loadfn[255]='\0';
        } else if (!strcmp(argv[i],"--norandio")){
            *no_randio = 1;
        }
    }
}

/* ---------------- Workload builders ---------------- */
static void workload_preset_small(Queue* w){
    workload_add(w,1,0,5);
    workload_add(w,2,0,3);
    workload_add(w,3,2,6);
    workload_add(w,4,4,4);
}
static void workload_preset_medium(Queue* w){
    int tid=1;
    int arr[]={0,1,2,3,4, 6,7,9,11,13};
    int bur[]={3,4,2,6,5, 3,4,7, 2, 5};
    for(int i=0;i<10;i++) workload_add(w, tid++, arr[i], bur[i]);
}
static void workload_preset_large(Queue* w){
    int tid=1;
    for(int i=0;i<20;i++){
        int at = (i<10)? (i/2) : i;
        int bt = 1 + (i%7);
        workload_add(w, tid++, at, bt);
    }
}

static void workload_fill_generator(Queue* w){
    int n           = read_int("  Number of jobs: ");
    int min_arrival = read_int("  Min arrival time: ");
    int max_arrival = read_int("  Max arrival time: ");
    int min_burst   = read_int("  Min burst length: ");
    int max_burst   = read_int("  Max burst length: ");
    puts("  Pattern: 0=Random, 1=Staggered, 2=Bursty");
    int pat         = read_int("  Pattern: ");
    unsigned seed   = (unsigned)read_int("  RNG seed: ");
    srand(seed?seed:42);
    int gap=0, group=0;
    if (pat==1) gap   = read_int("  Stagger gap (ticks): ");
    if (pat==2) group = read_int("  Bursty group size: ");

    for (int i=1;i<=n;i++){
        int at=0, bt=1;
        if (pat==0) at = rnd(min_arrival, max_arrival);
        else if (pat==1){
            at = min_arrival + (i-1)*gap;
            if (at>max_arrival) at=max_arrival;
        } else {
            int g=(group>0)?group:1;
            int block = (i-1)/g;
            int span=(max_arrival>min_arrival)?(max_arrival-min_arrival):0;
            int steps = (n/g>0)?(n/g):1;
            at = min_arrival + block*( (span/steps)+1 );
            if (at>max_arrival) at=max_arrival;
        }
        bt = rnd(min_burst, max_burst);
        if (bt<=0) bt=1;
        workload_add(w, i, at, bt);
    }
}

static int parse3(const char* s, int* a,int* b,int* c){
    return (sscanf(s," %d , %d , %d ", a,b,c)==3) || (sscanf(s," %d %d %d ", a,b,c)==3);
}
static int parse2(const char* s, int* a,int* b){
    return (sscanf(s," %d , %d ", a,b)==2) || (sscanf(s," %d %d ", a,b)==2);
}
static void workload_fill_from_file(Queue* w, const char* path){
    FILE* f=fopen(path,"r");
    if(!f){ perror("open --load file"); return; }
    char line[256]; int tid_auto=1, cnt=0;
    while(fgets(line,sizeof(line),f)){
        char* p=line; while(isspace((unsigned char)*p)) ++p;
        if (*p=='\0' || *p=='#') continue;
        int tid,at,bt;
        if (parse3(p,&tid,&at,&bt)){
            if (bt<=0) bt=1; workload_add(w,tid,at,bt); cnt++;
        } else if (parse2(p,&at,&bt)){
            if (bt<=0) bt=1; workload_add(w,tid_auto++,at,bt); cnt++;
        } else {
            /* skip malformed lines */
        }
    }
    fclose(f);
    printf("Loaded %d jobs from %s\n", cnt, path);
}

/* ---------------- logging/sim helpers ---------------- */
static void collect_completions(CPU* cpu, Queue* finished) {
    for (int i = 0; i < cpu->ncores; ++i) {
        Thread* t = cpu->core[i];
        if (!t) continue;
        if (t->remaining == 0) {
            (void)cpu_unbind_core(cpu, i);
            t->state = ST_FINISHED;
            if (t->finish_time < 0) t->finish_time = SIM_TIME;
            q_push(finished, t);
        }
    }
}
static int all_done(const Queue* ready, const Queue* waiting, const CPU* cpu) {
    if (!q_empty((Queue*)ready))   return 0;
    if (!q_empty((Queue*)waiting)) return 0;
    for (int i = 0; i < cpu->ncores; ++i)
        if (cpu->core[i]) return 0;
    return 1;
}
static void random_interrupts(const InterruptConfig* cfg, CPU* cpu, Queue* waiting, Log* log)  {
    if (!cfg || !cfg->enable_random) return;
    for (int c = 0; c < cpu->ncores; ++c) {
        Thread* t = cpu->core[c];
        if (!t) continue;
        if ((rand()%100) < cfg->pct_io) {
            int dur = rnd(cfg->io_min, cfg->io_max);
            int unblock = SIM_TIME + dur;
            (void)cpu_unbind_core(cpu, c);
            t->state = ST_WAITING;
            t->unblocked_at = unblock;
            q_push(waiting, t);
            log_io_event(log, SIM_TIME, c, t->tid, dur, unblock);
        }
    }
}

/* ---------------- local schedulers ---------------- */
typedef int (*BetterFn)(const Thread*, const Thread*);
typedef enum { ALG_FIFO1=1, ALG_SJF1=2, ALG_PRI1=3, ALG_RR1=4 } ALG1;

static int rr_quantum = 1;
static int slice_left[MAX_CORES];
static int prio_map[PRIO_MAP_SIZE];

static void prio_clear(void){ for (int i=0;i<PRIO_MAP_SIZE;i++) prio_map[i]=0; }
static void prio_set(int tid,int p){ if (tid>=0 && tid<PRIO_MAP_SIZE) prio_map[tid]=p; }

static int better_sjf(const Thread* a, const Thread* b){
    if (a->remaining != b->remaining) return a->remaining < b->remaining;
    if (a->arrival_time != b->arrival_time) return a->arrival_time < b->arrival_time;
    return a->tid < b->tid;
}
static int better_pri(const Thread* a, const Thread* b){
    int pa = (a->tid>=0 && a->tid<PRIO_MAP_SIZE)? prio_map[a->tid]:0;
    int pb = (b->tid>=0 && b->tid<PRIO_MAP_SIZE)? prio_map[b->tid]:0;
    if (pa != pb) return pa < pb;
    if (a->arrival_time != b->arrival_time) return a->arrival_time < b->arrival_time;
    return a->tid < b->tid;
}
static Thread* pop_best(Queue* q, BetterFn better){
    if (q_empty(q)) return NULL;
    Thread *best=q->front, *best_prev=NULL, *prev=NULL, *cur=q->front;
    for (; cur; prev=cur, cur=cur->next){
        if (better(cur,best)){ best=cur; best_prev=prev; }
    }
    if (best_prev) best_prev->next = best->next;
    else q->front = best->next;
    if (!best->next) q->rear = best_prev;
    best->next=NULL; q->size--;
    return best;
}

static void schedule_fifo(CPU* cpu, Queue* ready){
    while (cpu_any_idle(cpu)){
        Thread* t = q_pop(ready);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}
static void schedule_sjf(CPU* cpu, Queue* ready){
    while (cpu_any_idle(cpu)){
        Thread* t = pop_best(ready, better_sjf);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}
static void schedule_pri(CPU* cpu, Queue* ready){
    while (cpu_any_idle(cpu)){
        Thread* t = pop_best(ready, better_pri);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}
static void schedule_rr(CPU* cpu, Queue* ready){
    for (int c=0;c<cpu->ncores && c<MAX_CORES;++c){
        Thread* t = cpu->core[c];
        if (!t) continue;
        if (slice_left[c]<=0) slice_left[c]=rr_quantum;
        slice_left[c]-=1;
        if (slice_left[c]==0 && t->remaining>0){
            Thread* p = cpu_unbind_core(cpu,c);
            if (p){ p->state = ST_READY; q_push(ready,p); }
        }
    }
    while (cpu_any_idle(cpu)){
        Thread* t = q_pop(ready);
        if (!t) break;
        int idx = cpu_bind_first_idle(cpu, t);
        if (idx>=0 && idx<MAX_CORES) slice_left[idx]=rr_quantum;
    }
}

/* ---------------- main ---------------- */
int main(int argc, char** argv){
    UIMode ui; Algo algo; int quantum, cores, preset, no_randio;
    char loadfn[256];
    parse_args(argc,argv,&ui,&algo,&quantum,&cores,&preset,loadfn,&no_randio);

    // Build workload according to UI mode
    Queue workload; workload_init(&workload);

    if (ui==UI_GEN){
        puts("\n--- Job Generator ---");
        workload_fill_generator(&workload);
    } else if (ui==UI_PRESET){
        puts("\n--- Preset ---");
        if (preset==2) workload_preset_medium(&workload);
        else if (preset==3) workload_preset_large(&workload);
        else workload_preset_small(&workload);
    } else {
        // UI_LOAD: hidden path to use dumped workload
        if (loadfn[0]) workload_fill_from_file(&workload, loadfn);
        else { fprintf(stderr,"--load path missing\n"); return 1; }
    }

    // #cores (UI_PRESET path wants cores before run; UI_GEN asks it here too)
    if (cores<=0) cores=1;
    if (ui==UI_GEN){
        cores = read_int("\nNumber of cores: ");
        if (cores<=0) cores=1;
    }

    // Priority values if needed
    if (algo==ALG_PRIORITY){
        puts("\nEnter priority per job (lower = higher priority):");
        for (Thread* p=workload.front; p; p=p->next){
            printf("  T%d: ", p->tid); fflush(stdout);
            int pr=0; if (scanf("%d",&pr)!=1) pr=0;
            prio_set(p->tid, pr);
        }
    }

    // Random I/O config (not for --norandio path)
    InterruptConfig intr = {0};
    if (!no_randio){
        puts("\nRandom I/O interrupts:");
        intr.enable_random = read_01("  Enable? (0/1): ");
        if (intr.enable_random){
            intr.pct_io = read_int("  IO probability (%): ");
            intr.io_min = read_int("  IO min duration: ");
            intr.io_max = read_int("  IO max duration: ");
        }
    }

    // init queues and cpu
    Queue ready, waiting, finished;
    q_init(&ready); q_init(&waiting); q_init(&finished);

    CPU cpu; cpu_init(&cpu, cores);
    int **trace = (int**)malloc(sizeof(int*)*cores);
    for (int c=0;c<cores;c++){
        trace[c]=(int*)malloc(sizeof(int)*MAX_TICKS);
        for (int t=0;t<MAX_TICKS;t++) trace[c][t]=-1;
    }
    cpu.run_trace=trace; cpu.trace_len=MAX_TICKS;

    Log log;
    if (log_open(&log, "sim_log.txt") != 0) { fprintf(stderr,"cannot open sim_log.txt\n"); return 1; }
    log_set_multiline(&log, 1);
    log_workload(&log, "Workload before simulation", &workload);
    log_interrupts_config(&log, intr.enable_random, intr.pct_io, intr.io_min, intr.io_max);

    // main loop
    SIM_TIME=0;
    workload_admit_tick(&workload,&ready,SIM_TIME);

    for (;;){
        workload_admit_tick(&workload,&ready,SIM_TIME);
        waiting_io_resolve(&waiting,&ready,SIM_TIME);
        if (!no_randio) random_interrupts(&intr,&cpu,&waiting,&log);

        switch (algo){
            case ALG_FIFO:     schedule_fifo(&cpu,&ready); break;
            case ALG_SJF:      schedule_sjf(&cpu,&ready);  break;
            case ALG_PRIORITY: schedule_pri(&cpu,&ready);  break;
            case ALG_RR:       rr_quantum = (quantum<=0)?1:quantum; schedule_rr(&cpu,&ready); break;
        }

        bump_queue_wait(&ready);
        log_snapshot(&log, SIM_TIME, &ready, &waiting, &cpu, &finished);
        cpu_step(&cpu);
        collect_completions(&cpu, &finished);
        if (all_done(&ready,&waiting,&cpu)) break;
    }

    log_snapshot(&log, SIM_TIME, &ready, &waiting, &cpu, &finished);
    log_final_averages(&log, &finished);
    log_close(&log);

    if (write_core_trace_default(&cpu)==0) puts("Wrote per-core trace to core_trace.txt");

    // cleanup
    while(!q_empty(&finished)) free(q_pop(&finished));
    for (int c=0;c<cores;c++) free(trace[c]); free(trace); free(cpu.core);
    return 0;
}