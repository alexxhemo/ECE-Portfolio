#ifndef DISPATCH_H
#define DISPATCH_H
#include "sim.h"

/* Which scheduler to use */
typedef enum {
    DISP_FIFO = 0,
    DISP_SJF,
    DISP_PRIORITY,
    DISP_RR
} DispatchAlgo;

/* Function pointer type for any scheduler */
typedef void (*DispatchFn)(CPU* cpu, Queue* ready);

/* Get a scheduler by enum, and a readable name */
DispatchFn   dispatch_get(DispatchAlgo algo);
const char*  dispatch_name(DispatchAlgo algo);

/* Concrete policies */
void dispatch_fifo(CPU* cpu, Queue* ready);
void dispatch_sjf(CPU* cpu, Queue* ready);
void dispatch_priority(CPU* cpu, Queue* ready);
void dispatch_rr(CPU* cpu, Queue* ready);

/* Tunables */
void dispatch_set_rr_quantum(int q);            // RR time slice (ticks)
void dispatch_clear_priorities(void);           // reset all priorities to 0
void dispatch_set_priority(int tid, int prio);  // lower = higher

#endif