#include "dispatch.h"

/* ---------- helpers ---------- */
typedef int (*BetterFn)(const Thread*, const Thread*);

static Thread* pop_best(Queue* q, BetterFn better) {
    if (q_empty(q)) return NULL;
    Thread *best_prev = NULL, *prev = NULL, *cur = q->front;
    Thread *best = cur;
    for (; cur; prev = cur, cur = cur->next) {
        if (better(cur, best)) { best = cur; best_prev = prev; }
    }
    // unlink best
    if (best_prev) best_prev->next = best->next;
    else           q->front = best->next;
    if (!best->next) q->rear = best_prev;
    best->next = NULL;
    q->size--;
    return best;
}

/* ---------- FIFO ---------- */
void dispatch_fifo(CPU* cpu, Queue* ready) {
    while (cpu_any_idle(cpu)) {
        Thread* t = q_pop(ready);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}

/* ---------- SJF (non-preemptive: shortest remaining) ---------- */
static int better_sjf(const Thread* a, const Thread* b) {
    if (a->remaining != b->remaining) return a->remaining < b->remaining;
    if (a->arrival_time != b->arrival_time) return a->arrival_time < b->arrival_time;
    return a->tid < b->tid;
}
void dispatch_sjf(CPU* cpu, Queue* ready) {
    while (cpu_any_idle(cpu)) {
        Thread* t = pop_best(ready, better_sjf);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}

/* ---------- Priority (non-preemptive) ---------- */
#define PRIO_MAP_SIZE 10000
static int prio_map[PRIO_MAP_SIZE];   /* default 0 */

void dispatch_clear_priorities(void){ for (int i=0;i<PRIO_MAP_SIZE;i++) prio_map[i]=0; }
void dispatch_set_priority(int tid, int prio){
    if (tid>=0 && tid<PRIO_MAP_SIZE) prio_map[tid] = prio;
}
static int better_prio(const Thread* a, const Thread* b) {
    int pa = (a->tid>=0 && a->tid<PRIO_MAP_SIZE) ? prio_map[a->tid] : 0;
    int pb = (b->tid>=0 && b->tid<PRIO_MAP_SIZE) ? prio_map[b->tid] : 0;
    if (pa != pb) return pa < pb;                        // lower wins
    if (a->arrival_time != b->arrival_time) return a->arrival_time < b->arrival_time;
    return a->tid < b->tid;
}
void dispatch_priority(CPU* cpu, Queue* ready) {
    while (cpu_any_idle(cpu)) {
        Thread* t = pop_best(ready, better_prio);
        if (!t) break;
        cpu_bind_first_idle(cpu, t);
    }
}

/* ---------- Round Robin (preemptive) ---------- */
static int rr_q = 1;
#define MAX_CORES 64
static int slice_left[MAX_CORES];

void dispatch_set_rr_quantum(int q){ rr_q = (q<=0)?1:q; }

void dispatch_rr(CPU* cpu, Queue* ready) {
    /* tick begin: age slices, preempt if slice ended */
    for (int c=0; c<cpu->ncores && c<MAX_CORES; ++c) {
        Thread* t = cpu->core[c];
        if (!t) continue;
        if (slice_left[c] <= 0) slice_left[c] = rr_q;     // init on first bind
        slice_left[c] -= 1;
        if (slice_left[c] == 0 && t->remaining > 0) {
            preempt_to_ready(cpu, c, ready);              // send back to ready
        }
    }
    /* bind to idle cores FIFO-style; reset slice for newcomers */
    while (cpu_any_idle(cpu)) {
        Thread* t = q_pop(ready);
        if (!t) break;
        int idx = cpu_bind_first_idle(cpu, t);
        if (idx>=0 && idx<MAX_CORES) slice_left[idx] = rr_q;
    }
}

/* ---------- selector ---------- */
DispatchFn dispatch_get(DispatchAlgo algo) {
    switch (algo) {
        case DISP_FIFO:     return dispatch_fifo;
        case DISP_SJF:      return dispatch_sjf;
        case DISP_PRIORITY: return dispatch_priority;
        case DISP_RR:       return dispatch_rr;
        default:            return dispatch_fifo;
    }
}
const char* dispatch_name(DispatchAlgo algo) {
    switch (algo) {
        case DISP_FIFO:     return "FCFS/FIFO";
        case DISP_SJF:      return "SJF";
        case DISP_PRIORITY: return "PRIORITY";
        case DISP_RR:       return "RR";
        default:            return "unknown";
    }
}

